#!/bin/bash
#
echo "Start installation..."
# Prompt the user for the target install directory.
read -r -p "Enter the install directory full path: " LOGGER_HOME_PATH
echo ">>>>> Set LOGGER_HOME_PATH=$LOGGER_HOME_PATH"

# Create target install directory
if [ ! -d "$LOGGER_HOME_PATH" ]; then
    echo ">>>>> Directory $LOGGER_HOME_PATH does not exist."
    mkdir -p "$LOGGER_HOME_PATH" || { echo ">>>>> Failed to create directory"; exit 1; }
fi

# Allow the user to confirm the target install directory is accurately created
echo ">>>>> Created directory: $LOGGER_HOME_PATH"
read -r -p "Confirm directory was accurately created [y/n]: " CONFIRM
if [ "$CONFIRM" != "y" ]; then
	echo ">>>>> Aborting install"
	exit 1;
else
	echo ">>>>> Your confirmation is -> $CONFIRM"
fi
echo ">>>>> Create subdirectories in $LOGGER_HOME_PATH"
# Create all subdirectories
mkdir -p "$LOGGER_HOME_PATH/LoggerOutput"
mkdir -p "$LOGGER_HOME_PATH/LoggerSecureVault"
mkdir -p "$LOGGER_HOME_PATH/LoggerLibFree"
mkdir -p "$LOGGER_HOME_PATH/user_application"
ls -lrt $LOGGER_HOME_PATH
#
# Copy appropriate files to subdirectories
echo ">>>>> Installing files to subdirectories in $LOGGER_HOME_PATH..."
cp LoggerLibFree.a $LOGGER_HOME_PATH/LoggerLibFree/.
cp LoggerMessageDefines.txt $LOGGER_HOME_PATH/LoggerSecureVault/.
cp Wandi-SSAL-examples.c $LOGGER_HOME_PATH/user_application/.
cp Makefile $LOGGER_HOME_PATH/user_application/.
ls -lrt $LOGGER_HOME_PATH/*
#
# make Wandi-SSAL-example user application
cd $LOGGER_HOME_PATH/user_application
echo ">>>>> Biuld Wandi-SSAL-example.c in $LOGGER_HOME_PATH/user_application"
make all
#
cat << EOF >example_app.sh
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH
echo "Using LOGGER_HOME_PATH: $LOGGER_HOME_PATH"
./Wandi-SSAL-examples
EOF
#cp example_app.sh $LOGGER_HOME_PATH/user_application/.
chmod 777 $LOGGER_HOME_PATH/user_application/example_app.sh
#
echo ">>>>> Installed directories and files:"
# List the target installed directories and files
ls -lrt $LOGGER_HOME_PATH/*
#
echo -e "\nGo to $LOGGER_HOME_PATH/user_application directory."
echo "Run ./example_app.sh to execute Wandi-SSAL-examples.c program."
echo -e "Go to $LOGGER_HOME_PATH/LoggerOutput directory to view output files.\n"
#
echo ">>>>> Installation complete!"

int LoggerStartUp();
int LoggerAppsMsg(int devProd, int message_group, int severity, char *message_string, ...);
int LoggerShutDown();

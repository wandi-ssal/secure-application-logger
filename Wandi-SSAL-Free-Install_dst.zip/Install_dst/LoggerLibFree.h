int LoggerStartUp();
int LoggerAppsMsg(int devProd, int , int , char *, ...);
int LoggerShutDown();

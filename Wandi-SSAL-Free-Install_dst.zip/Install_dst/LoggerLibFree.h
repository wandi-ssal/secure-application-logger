int LoggerStartUp();
int LoggerAppsMsg(int, int , int , char * , ...);
int LoggerShutDown();
